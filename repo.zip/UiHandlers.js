var MyApp = MyApp || {};
MyApp.UIHandler = (function() {
  // future UI methods
  return {};
})();
